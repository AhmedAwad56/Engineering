# Claude Skills — Project & Construction Management

Curated from [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) (MIT licence, see `LICENSE-claude-skills`).
Each folder is a self-contained skill (`SKILL.md` + optional `scripts/`, `references/`, `assets/`). Scripts are Python 3 standard-library only.

> Note: the source library contains **no construction-specific skills** — it is written for software/SaaS businesses.
> Folder 02 holds general management skills whose methods transfer to construction delivery; expect to adapt
> examples (SaaS vendors → subcontractors, sprints → look-ahead programmes, ARR → cash flow).

## 01-project-management (full PM suite from the source)

| Skill | Use it for |
|---|---|
| senior-pm | Portfolio health dashboard, risk matrix / EMV & Monte Carlo, resource capacity, executive reporting |
| pm-skills | Router that coordinates the other PM skills (health reports, delivery audits) |
| meeting-analyzer | Reviews meeting transcripts for decisions, patterns and coaching feedback |
| team-communications | Progress/Plans/Problems updates, status reports, leadership updates, incident reports |
| scrum-master | Sprint planning, velocity, retrospectives, blocker tracking |
| jira-expert | Jira projects, JQL, workflows, dashboards |
| confluence-expert | Confluence spaces, documentation structure, page templates |
| atlassian-admin | Atlassian users, permissions, governance |
| atlassian-templates | Jira/Confluence templates and blueprints |

## 02-construction-applicable (adaptable to construction PM/CM)

| Skill | Construction use |
|---|---|
| contract-and-proposal-writer | Proposals, scopes of work, NDAs (not FIDIC-specific — not legal advice) |
| rfp-responder | Tender / RFQ responses, compliance matrices for mandatory vs weighted requirements |
| procurement-optimizer | Spend categorisation, purchasing-cycle bottlenecks, supplier rationalisation |
| vendor-management | Subcontractor/supplier scorecards, SLA tracking, third-party risk |
| capacity-planner | Manpower/headcount planning and utilisation risk |
| process-mapper | Mapping approvals (IR, MIR, RFI, submittal cycles), cycle times and bottlenecks |
| meetings | Agendas with outcomes, turning minutes into owned action items |
| weekly-review | Weekly close-out of open items and stalled commitments |
| financial-analyst | Budget-vs-actual variance, forecasts, cash-flow projections |
| postmortem | Blameless 5-Whys lessons-learned with change register |
| scenario-war-room | Compound what-if risk modelling (delay + cost + resource shocks together) |

## Installing in Claude
- **claude.ai:** zip an individual skill folder and upload it under Settings → Capabilities → Skills.
- **Claude Code:** copy skill folders into `~/.claude/skills/` (personal) or `.claude/skills/` (per project).
